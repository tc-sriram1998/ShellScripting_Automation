Hi
Hello how are you
This is devops course
From Singam

My manager is good

Manager is able to manage all things


version=1.2.3.4

tenth session will be handson
