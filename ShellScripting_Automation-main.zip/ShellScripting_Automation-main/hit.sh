#!/bin/sh
curl  -X PUT -u "singampallipraveenkumar@gmail.com:XkO2YJUvaof4fsvLAqtM63EA"--data '{"update":{"labels":[{"add":"DEMO"}]}}' --header "Content-Type: application/json" "Authorization: Basic XkO2YJUvaof4fsvLAqtM63EA" https://singam.atlassian.net/rest/api/3/issue/SA-1

